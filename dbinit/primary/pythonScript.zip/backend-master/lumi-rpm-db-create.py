# built with python 3.8.2
# run this file with "python lumi-rpm-db-create.py"

# terminal commands
# mysql <-- opens the terminal line
# SHOW DATABASES; <-- view the database list
# USE <database_name>; <-- connect to the DB
# SHOW TABLES; <-- view all the tables in the DB
# DESC <table_name>; <-- view the table schema

# importing rquired libraries
import mysql.connector

dbname = "luminhealth"


hostname = "127.0.0.1"
username = "root"
password = "root"
port = 3306


# uncomment this to run on the box
dataBase = mysql.connector.connect(
  host=hostname,
  port=port,
  user=username,
  passwd=password
)
# preparing a cursor object
cursorObject = dataBase.cursor()

# uncomment this line to drop it before creating
cursorObject.execute(f"DROP DATABASE {dbname}")

# creating database
cursorObject.execute(f"CREATE DATABASE {dbname}")

dataBase.close()

# connecting to the database
dataBase = mysql.connector.connect(
                     host=hostname,
                     port=port,
                     user=username,
                     passwd=password,
                     database=dbname)

# preparing a cursor object
cursorObject = dataBase.cursor()

# creating Patient Demogrpahic table
lumiPatientRecord = """CREATE TABLE Patient_Demographic (
                   lumi_patient_id INT AUTO_INCREMENT,
                   source_system_patient_id BIGINT NOT NULL,
                   first_name VARCHAR(50) NOT NULL,
                   middle_name VARCHAR(50),
                   last_name VARCHAR(50) NOT NULL,
                   dob DATETIME NOT NULL,
                   gender VARCHAR(10) NOT NULL,
                   primary_phone VARCHAR(15) NOT NULL,
                   primary_phone_type VARCHAR(15) NOT NULL,
                   secondary_phone VARCHAR(15),
                   secondary_phone_type VARCHAR(15),
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (lumi_patient_id, source_system_patient_id)
                   )"""

# table created
cursorObject.execute(lumiPatientRecord)

# creating Patient Device table
patientDeviceRecord = """CREATE TABLE Patient_Device (
                   id INT AUTO_INCREMENT,
                   lumi_patient_id INT NOT NULL,
                   type VARCHAR(50) NOT NULL,
                   manufactor VARCHAR(50) NOT NULL,
                   model VARCHAR(50) NOT NULL,
                   serial VARCHAR(50) NOT NULL,
                   ship_date DATETIME,
                   deliviered_date DATETIME,
                   activated_date DATETIME,
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id, type)
                   )"""

# table created
cursorObject.execute(patientDeviceRecord)

# creating Patient Diagnosis table
patientDiagnosisRecord = """CREATE TABLE Patient_Diagnosis (
                   id INT AUTO_INCREMENT,
                   lumi_patient_id INT NOT NULL,
                   icd10_code VARCHAR(50) NOT NULL,
                   icd10_name TEXT NOT NULL,
                   diagnosis_icd10_url TEXT,
                   diagnosis_date DATETIME,
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id)
                   )"""

# table created
cursorObject.execute(patientDiagnosisRecord)

# creating Patient Medications table
patientMedicationRecord = """CREATE TABLE Patient_Medication (
                   id INT AUTO_INCREMENT,
                   lumi_patient_id INT NOT NULL,
                   ndc_code VARCHAR(50),
                   generic_name VARCHAR(50) NOT NULL,
                   rx_norm INT NOT NULL,
                   dosage VARCHAR(50),
                   category VARCHAR(50) NOT NULL,
                   start_date DATETIME,
                   end_date DATETIME,
                   current_taking BOOLEAN NOT NULL,
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id)
                   )"""

# table created
cursorObject.execute(patientMedicationRecord)

# creating Patient Care table
patientCareRecord = """CREATE TABLE Patient_Care_Team (
                   id INT AUTO_INCREMENT,
                   lumi_patient_id INT NOT NULL,
                   cardiologist_npi BIGINT,
                   cardiologist_name VARCHAR(150) NOT NULL,
                   cardiologist_phone VARCHAR(15),
                   pcp_npi BIGINT,
                   pcp_name VARCHAR(150) NOT NULL,
                   pcp_phone VARCHAR(15),
                   care_quarterback VARCHAR(150),
                   care_quarterback_phone VARCHAR(15),
                   clinical_pharmacist VARCHAR(150),
                   clinical_pharmacist_phone VARCHAR(15),
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id, lumi_patient_id)
                   )"""

# table created
cursorObject.execute(patientCareRecord)

# creating Patient Device BP table
patientDeviceBPRecord = """CREATE TABLE Patient_Device_BP (
                   id INT AUTO_INCREMENT,
                   lumi_patient_id INT NOT NULL,
                   patient_device_id INT NOT NULL,
                   reading_datetime DATETIME NOT NULL,
                   diastolic_value INT NOT NULL,
                   systolic_value INT NOT NULL,
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id)
                   )"""

# table created
cursorObject.execute(patientDeviceBPRecord)

# creating Patient Device Scale table
patientDeviceScaleRecord = """CREATE TABLE Patient_Device_Scale (
                   id INT AUTO_INCREMENT,
                   lumi_patient_id INT NOT NULL,
                   patient_device_id INT NOT NULL,
                   reading_datetime DATETIME NOT NULL,
                   weight_lbs DECIMAL NOT NULL,
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id)
                   )"""

# table created
cursorObject.execute(patientDeviceScaleRecord)

# creating Team Member Profile table
careTeamRecord = """CREATE TABLE Care_Team_Member_Profile (
                   id INT AUTO_INCREMENT,
                   care_team_member_type VARCHAR(15) NOT NULL,
                   government_id VARCHAR(15) NOT NULL,
                   first_name VARCHAR(50) NOT NULL,
                   middle_name VARCHAR(50),
                   last_name VARCHAR(50) NOT NULL,
                   dob DATETIME NOT NULL,
                   gender VARCHAR(10) NOT NULL,
                   phone_number VARCHAR(15) NOT NULL,
                   email VARCHAR(50) NOT NULL,
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id)
                   )"""

# table created
cursorObject.execute(careTeamRecord)

# creating Team Member Profile table
careTeamMemberPerformanceRecord = """CREATE TABLE Care_Team_Member_Performance (
                   id INT AUTO_INCREMENT,
                   care_team_member_id INT NOT NULL,
                   patient_engagement_score INT NOT NULL,
                   coordination_score INT NOT NULL,
                   clinical_score INT NOT NULL,
                   patient_case_load INT NOT NULL,
                   patient_intervention_load INT NOT NULL,
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id)
                   )"""

# table created
cursorObject.execute(careTeamMemberPerformanceRecord)

# creating Interventions table
interventionsRecord = """CREATE TABLE Interventions (
                   id INT AUTO_INCREMENT,
                   lumi_patient_id INT NOT NULL,
                   care_team_member_id INT NOT NULL,
                   intervention_code_id INT NOT NULL,
                   patient_device_id INT NOT NULL,
                   priority INT NOT NULL,
                   is_complete BOOLEAN NOT NULL,
                   due_date DATETIME NOT NULL,
                   estimated_time INT NOT NULL,
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id)
                   )"""

# table created
cursorObject.execute(interventionsRecord)

# creating Intervention Codes table
interventionCodeRecord = """CREATE TABLE Intervention_Codes (
                   id INT AUTO_INCREMENT,
                   name TEXT NOT NULL,
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id)
                   )"""

# table created
cursorObject.execute(interventionCodeRecord)

# creating Interventions History table
interventionHistoryRecord = """CREATE TABLE Interventions_History (
                   id INT AUTO_INCREMENT,
                   care_team_member_id INT NOT NULL,
                   priority INT NOT NULL,
                   due_date DATETIME NOT NULL,
                   estimated_time INT NOT NULL,
                   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                   PRIMARY KEY (id)
                   )"""

# table created
cursorObject.execute(interventionHistoryRecord)

# disconnecting from server
dataBase.close()
