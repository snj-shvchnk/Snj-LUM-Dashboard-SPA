# built with python 3.8.2
# run this file with "python lumi-rpm-db-create.py"

# terminal commands
# mysql <-- opens the terminal line
# SHOW DATABASES; <-- view the database list
# USE <database_name>; <-- connect to the DB
# SHOW TABLES; <-- view all the tables in the DB
# DESC <table_name>; <-- view the table schema

# importing rquired libraries
import mysql.connector
# import csv
from sqlalchemy import create_engine
import pathlib
import os
import pandas as pd

dbname = "luminhealth"
hostname = "127.0.0.1"
username = "root"
password = "root"
port = 3306

dirpath = pathlib.Path(__file__).parent / "sample_data"

# connecting to the database
# engine = mysql.connector.connect(
#                     host=hostname,
#                     port=port,
#                     user=username,
#                     passwd=password,
#                     database=dbname)




engine = create_engine(f"pymysql://{username}:{password}@{hostname}:{port}/{dbname}")

# preparing a cursor object
# cursorObject = connDB.cursor(buffered=True)

# cursorObject.execute('''
# SELECT * FROM Patient_Demographic
# ''')
# df = pd.DataFrame(cursorObject.fetchall())
# print(df)

for file in dirpath.iterdir():
    if '.xlsx' in os.path.splitext(file)[-1]:
        print(f'found {file}')
        xl = pd.ExcelFile(file)

        p_demographic = xl.parse('Patient Demographic')
        p_demographic.to_sql('Patient_Demographic', con=engine, index=False, if_exists='append', chunksize=1000)

        patients = {}
        # import pdb; pdb.set_trace()
        result = engine.execute("select source_system_patient_id, lumi_patient_id from Patient_Demographic")
        for row in result:
            patients[row[0]] = row[1]
        result.close()

        p_devices = xl.parse('Patient-Device')
        i=0
        for row in p_devices.iterrows():
            p_devices.loc[i, 'source_system_patient_id'] = patients[row[1][0]]
            i = i + 1
        # import pdb; pdb.set_trace()

        p_devices = p_devices.rename(columns = {'source_system_patient_id' : 'lumi_patient_id'})

        p_devices.to_sql('Patient_Device', con=engine, index=False, if_exists='append', chunksize=1000)

        # import pdb; pdb.set_trace()

        p_diagnosis = xl.parse('Patient Diagnoses')
        i=0
        for row in p_diagnosis.iterrows():
            p_diagnosis.loc[i, 'source_system_patient_id'] = patients[row[1][0]]
            i = i + 1
        p_diagnosis = p_diagnosis.rename(columns = {'source_system_patient_id' : 'lumi_patient_id'})

        p_diagnosis.to_sql('Patient_Diagnosis', con=engine, index=False, if_exists='append', chunksize=1000)

        # import pdb; pdb.set_trace()

        p_meds = xl.parse('Patient Medications')
        i=0
        for row in p_meds.iterrows():
            p_meds.loc[i, 'source_system_patient_id'] = patients[row[1][0]]
            i = i + 1
        p_meds = p_meds.rename(columns = {'source_system_patient_id' : 'lumi_patient_id'})

        p_meds.to_sql('Patient_Medication', con=engine, index=False, if_exists='append', chunksize=1000)

        # import pdb; pdb.set_trace()

        pct = xl.parse('Patient- Patient Care Team')
        i=0
        for row in pct.iterrows():
            pct.loc[i, 'source_system_patient_id'] = patients[row[1][0]]
            i = i + 1
        pct = pct.rename(columns = {'source_system_patient_id' : 'lumi_patient_id'})

        pct.to_sql('Patient_Care_Team', con=engine, index=False, if_exists='append', chunksize=1000)


        devices = {}
        result = engine.execute("select serial, id from Patient_Device")
        for row in result:
            devices[row[0]] = row[1]
        result.close()

        pd_bp = xl.parse('Patient-Device-BP')
        i=0
        for row in pd_bp.iterrows():
            pd_bp.loc[i, 'source_system_patient_id'] = patients[row[1][0]]
            pd_bp.loc[i, 'device_serial'] = devices[row[1][1]]
            i = i + 1
        pd_bp = pd_bp.rename(columns = {'source_system_patient_id' : 'lumi_patient_id'})

        pd_bp = pd_bp.rename(columns = {'device_serial' : 'patient_device_id'})

        pd_bp.to_sql('Patient_Device_BP', con=engine, index=False, if_exists='append', chunksize=1000)

        # import pdb; pdb.set_trace()

        pd_scale = xl.parse('Patient-Device-Scale')
        i=0
        for row in pd_scale.iterrows():
            pd_scale.loc[i, 'source_system_patient_id'] = patients[row[1][0]]
            pd_scale.loc[i, 'device_serial'] = devices[row[1][1]]
            i = i + 1
        pd_scale = pd_scale.rename(columns = {'source_system_patient_id' : 'lumi_patient_id'})

        pd_scale = pd_scale.rename(columns = {'device_serial' : 'patient_device_id'})

        pd_scale.to_sql('Patient_Device_Scale', con=engine, index=False, if_exists='append', chunksize=1000)

        # import pdb; pdb.set_trace()

        ctm_profiles = xl.parse('Care Team Member Profiles')

        ctm_profiles.to_sql('Care_Team_Member_Profile', con=engine, index=False, if_exists='append', chunksize=1000)

        care_team = {}
        result = engine.execute("select government_id, id from Care_Team_Member_Profile")
        for row in result:
            care_team[row[0]] = row[1]
        result.close()

        ctm_perf = xl.parse('Care Team Member-Performance')
        i=0
        for row in ctm_perf.iterrows():
            ctm_perf.loc[i, 'government_id'] = care_team[str(row[1][0])]
            i = i + 1
        ctm_perf = ctm_perf.rename(columns = {'government_id' : 'care_team_member_id'})

        ctm_perf.to_sql('Care_Team_Member_Performance', con=engine, index=False, if_exists='append', chunksize=1000)

        intervenion_codes = xl.parse('Intervention Codes')

        intervenion_codes.to_sql('Intervention_Codes', con=engine, index=False, if_exists='append', chunksize=1000)

        # import pdb; pdb.set_trace()

        p_intervent = xl.parse('Patient Intervention')
        i=0
        for row in p_intervent.iterrows():
            p_intervent.loc[i, 'government_id'] = care_team[str(row[1][0])]
            p_intervent.loc[i, 'source_system_patient_id'] = patients[row[1][1]]
            p_intervent.loc[i, 'device_serial'] = devices[row[1][2]]
            i = i + 1
        p_intervent = p_intervent.rename(columns = {'source_system_patient_id' : 'lumi_patient_id'})

        p_intervent = p_intervent.rename(columns = {'device_serial' : 'patient_device_id'})
        p_intervent = p_intervent.rename(columns = {'government_id' : 'care_team_member_id'})

        p_intervent.to_sql('Interventions', con=engine, index=False, if_exists='append', chunksize=1000)


# import pdb; pdb.set_trace()

